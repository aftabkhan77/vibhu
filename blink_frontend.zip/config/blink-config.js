export const blinkConfig = {
  title: "Blink", // Name of your website
  tagline: "A glimpse into your world", //Tagline of your website

  // Social Media Links
  socialMedia: {
    facebook: "https://www.facebook.com/",
    twitter: "https://www.twitter.com/",
    instagram: "https://www.instagram.com/",
    linkedIn: "https://www.linkedin.com/",
  },
};
