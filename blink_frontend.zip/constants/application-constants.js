export const SESSION_COOKIE_NAME = "user_session";
