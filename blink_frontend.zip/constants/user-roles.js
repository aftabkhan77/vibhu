export const userRoles = {
  ADMIN: "admin",
  USER: "user",
  MODERATOR: "moderator",
};
