import FacebookPixelIntegration from "@/analytics/facebook-pixel";
import GoogleAdsenseIntegration from "@/analytics/google-adsense";
import GoogleAnalyticsIntegration from "@/analytics/google-analytics";
import LinkedinInsightIntegration from "@/analytics/linkedin-insight";
import MicrosoftClarityIntegration from "@/analytics/microsoft-clarity";
import TiktokPixelIntegration from "@/analytics/tiktok-pixel";

export default function AnalyticsIntegration() {
  return (
    <>
      {/* Google Analytics */}
      {/* <GoogleAnalyticsIntegration /> */}
      {/* Google Adsense */}
      {/* <GoogleAdsenseIntegration /> */}
      {/* Facebook Pixel */}
      {/* <FacebookPixelIntegration /> */}
      {/* Linkedin Insight */}
      {/* <LinkedinInsightIntegration /> */}
      {/* Microsoft clarity */}
      {/* <MicrosoftClarityIntegration /> */}
      {/* Tiktok Pixel */}
      {/* <TiktokPixelIntegration /> */}
    </>
  );
}
