import PageLaoding from "@/components/shared/page-loading";

export default function BiolinkLoading() {
  return <PageLaoding />;
}
