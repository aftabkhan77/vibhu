import BioLinkList from "@/components/biolink/user/biolink-list";

export default function BioLinkListPage() {
  return <BioLinkList />;
}
