import QRCodeView from "@/components/qr-code/qr-code-view";

export default function QRCodePage() {
  return <QRCodeView />;
}
