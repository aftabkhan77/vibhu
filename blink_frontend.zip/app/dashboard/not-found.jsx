"use client";
import NotFound from "@/components/shared/not-found";

export default function NotFoundPage() {
  return <NotFound />;
}
