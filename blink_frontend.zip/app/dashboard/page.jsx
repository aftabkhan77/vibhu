import ViewDashboard from "@/components/dashboard/view-dashboard";

export default function Dashboard() {
  return <ViewDashboard />;
}
