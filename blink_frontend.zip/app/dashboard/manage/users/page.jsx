import UserList from "@/components/users/user-list";

export default function UsersListPage() {
  return <UserList />;
}
