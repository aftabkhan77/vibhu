import AdminSupportList from "@/components/support/admin/support-list";

export default function AdminSupportListPage() {
  return <AdminSupportList />;
}
