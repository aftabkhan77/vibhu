import AllBiolinkList from "@/components/biolink/administrator/all-biolink-list";

export default function BioLinkListPage() {
  return <AllBiolinkList />;
}
