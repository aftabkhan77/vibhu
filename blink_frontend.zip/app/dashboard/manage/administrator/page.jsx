import AdministratorList from "@/components/administrator/administrator-list";

export default function AdministratorListPage() {
  return <AdministratorList />;
}
