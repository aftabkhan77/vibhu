import SubscriptionList from "@/components/subscription/subscription-list";

// Paid subscribers list page
export default function SubscribersListPage() {
  return <SubscriptionList />;
}
