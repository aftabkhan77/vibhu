import SupportList from "@/components/support/support-list";

export default function SupportPage() {
  return <SupportList />;
}
