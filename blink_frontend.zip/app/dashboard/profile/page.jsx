import ViewProfile from "@/components/profile/view-profile";

export default function ProfilePage() {
  return <ViewProfile />;
}
