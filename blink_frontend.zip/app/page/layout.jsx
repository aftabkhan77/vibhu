import FooterSection from "@/components/shared/footer";
import NavigationMenu from "@/components/shared/navigation-menu";

export default function PageLayout({ children }) {
  return (
    <main>
      <div>
        <NavigationMenu />
      </div>
      <div>{children}</div>
      <FooterSection />
    </main>
  );
}
