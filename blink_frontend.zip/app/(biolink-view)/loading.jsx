import PageLaoding from "@/components/shared/page-loading";

export default function Loading() {
  return <PageLaoding />;
}
